# Architecture

- `web/`: static browser interface. User tasks and notes are persisted in browser local storage.
- `app/main.py`: FastAPI routes, validation, and optional Claude integration.
- `app/planner.py`: deterministic prioritization and time-budgeted scheduling.
- `tests/`: unit tests for the planner.

## Request flow

1. The browser sends the user's objective and current tasks to `POST /api/plan`.
2. Pydantic validates request fields and bounds the request size.
3. The local planner checks duplicate IDs, validates task metadata, detects dependency cycles, scores eligible tasks, and fits them into the time budget.
4. If explicitly enabled, the API asks Claude for additional planning advice.
5. The browser renders returned text using `textContent` rather than injecting HTML.

## Important limits

The current app is a single-user MVP. It does not provide authentication or cloud persistence. Do not expose it publicly with sensitive data until those capabilities and suitable operational controls are added. Claude API credentials must stay on the server.
