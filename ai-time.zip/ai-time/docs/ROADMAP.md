# AI TIME Roadmap

## MVP (current repository)
- [x] Responsive dashboard
- [x] Task creation and completion
- [x] Browser-local persistence
- [x] Focus/break timer
- [x] Deterministic time-budgeted planner
- [x] Optional Claude advice endpoint
- [x] API health check and planner tests

## Next
- [ ] PostgreSQL persistence and schema migrations
- [ ] Authentication and per-user authorization
- [ ] Calendar integration with explicit permissions
- [ ] Task dependencies in the UI
- [ ] Import/export user data
- [ ] Rate limits and request quotas
- [ ] Structured logging and monitoring
- [ ] End-to-end browser tests
- [ ] Accessibility audit
- [ ] CI workflow

## Later research ideas
- [ ] Knowledge graph for projects and notes
- [ ] Estimate uncertainty and learn from actual task durations
- [ ] Constraint-based schedule optimization
- [ ] Agent workflows with approvals and audit logs
- [ ] Evaluation suite for plan quality and hallucination rates

Do not mark a roadmap item complete until it is implemented and tested.
