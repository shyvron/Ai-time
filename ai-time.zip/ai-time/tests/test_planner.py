from datetime import datetime, timezone

import pytest

from app.planner import PlanInput, build_plan


NOW = datetime(2026, 10, 12, 12, 0, tzinfo=timezone.utc)


def test_schedules_high_priority_task_first():
    tasks = [
        {"id": "a", "title": "Low priority", "importance": 2,
         "estimated_minutes": 30, "dependencies": [], "status": "pending"},
        {"id": "b", "title": "Important", "importance": 10,
         "estimated_minutes": 30, "dependencies": [], "status": "pending"},
    ]
    result = build_plan(PlanInput(tasks, 30), now=NOW)
    assert result["schedule"][0]["id"] == "b"
    assert result["unscheduled_tasks"] == ["a"]


def test_unresolved_dependency_blocks_task():
    tasks = [
        {"id": "a", "title": "First", "importance": 5,
         "estimated_minutes": 20, "dependencies": [], "status": "pending"},
        {"id": "b", "title": "Second", "importance": 10,
         "estimated_minutes": 20, "dependencies": ["a"], "status": "pending"},
    ]
    result = build_plan(PlanInput(tasks, 60), now=NOW)
    assert result["blocked_tasks"] == ["b"]
    assert [x["id"] for x in result["schedule"]] == ["a"]


def test_detects_dependency_cycle():
    tasks = [
        {"id": "a", "title": "A", "importance": 5,
         "estimated_minutes": 20, "dependencies": ["b"], "status": "pending"},
        {"id": "b", "title": "B", "importance": 5,
         "estimated_minutes": 20, "dependencies": ["a"], "status": "pending"},
    ]
    with pytest.raises(ValueError, match="cycle"):
        build_plan(PlanInput(tasks, 60), now=NOW)


def test_empty_plan_is_valid():
    result = build_plan(PlanInput([], 0), now=NOW)
    assert result["schedule"] == []
    assert result["remaining_minutes"] == 0
