from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from math import sqrt
from typing import Any


@dataclass
class PlanInput:
    tasks: list[dict[str, Any]]
    available_minutes: int


def _urgency(deadline: str | datetime | None, now: datetime) -> float:
    if deadline is None:
        return 0.2
    if isinstance(deadline, str):
        try:
            deadline = datetime.fromisoformat(deadline.replace("Z", "+00:00"))
        except ValueError:
            return 0.2
    if deadline.tzinfo is None:
        deadline = deadline.replace(tzinfo=timezone.utc)
    hours = (deadline - now).total_seconds() / 3600
    if hours <= 0:
        return 1.0
    if hours <= 2:
        return 0.95
    if hours <= 8:
        return 0.8
    if hours <= 24:
        return 0.65
    if hours <= 72:
        return 0.45
    return 0.25


def build_plan(data: PlanInput, now: datetime | None = None) -> dict[str, Any]:
    now = now or datetime.now(timezone.utc)
    tasks = data.tasks
    if data.available_minutes < 0:
        raise ValueError("available_minutes must be non-negative")

    by_id: dict[str, dict[str, Any]] = {}
    for index, task in enumerate(tasks):
        task_id = str(task.get("id") or f"task-{index + 1}")
        if task_id in by_id:
            raise ValueError(f"Duplicate task ID: {task_id}")
        title = str(task.get("title", "")).strip()
        importance = int(task.get("importance", 5))
        duration = int(task.get("estimated_minutes", 30))
        if not title:
            raise ValueError(f"Task {task_id} needs a title")
        if not 1 <= importance <= 10:
            raise ValueError(f"Task {task_id} importance must be 1–10")
        if duration <= 0:
            raise ValueError(f"Task {task_id} duration must be positive")
        task["id"] = task_id
        by_id[task_id] = task

    # Detect dependency cycles before producing a schedule.
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(task_id: str) -> None:
        if task_id in visiting:
            raise ValueError(f"Dependency cycle detected at {task_id}")
        if task_id in visited:
            return
        visiting.add(task_id)
        task = by_id[task_id]
        for dependency in task.get("dependencies", []):
            if dependency in by_id:
                visit(dependency)
        visiting.remove(task_id)
        visited.add(task_id)

    for task_id in by_id:
        visit(task_id)

    completed = {
        task_id for task_id, task in by_id.items()
        if task.get("status") == "completed"
    }

    candidates: list[dict[str, Any]] = []
    blocked: list[str] = []

    for task_id, task in by_id.items():
        if task.get("status") in ("completed", "blocked"):
            continue
        deps = task.get("dependencies", [])
        unresolved = [dep for dep in deps if dep not in completed]
        if unresolved:
            blocked.append(task_id)
            continue

        urgency = _urgency(task.get("deadline"), now)
        importance = int(task.get("importance", 5)) / 10
        duration = int(task.get("estimated_minutes", 30))
        effort = 1 / sqrt(max(1, duration / 30))
        score = importance * 0.50 + urgency * 0.40 + effort * 0.10
        reasons = []
        if importance >= 0.8:
            reasons.append("High importance")
        if urgency >= 0.8:
            reasons.append("Deadline needs attention")
        if duration <= 30:
            reasons.append("Short task")
        candidates.append({
            "id": task_id,
            "title": task["title"],
            "importance": int(task.get("importance", 5)),
            "estimated_minutes": duration,
            "priority_score": round(score, 3),
            "urgency": round(urgency, 3),
            "dependencies": deps,
            "reason": reasons or ["Balanced priority"],
        })

    candidates.sort(key=lambda item: (-item["priority_score"], item["id"]))
    remaining = data.available_minutes
    scheduled = []
    unscheduled = []

    for item in candidates:
        if item["estimated_minutes"] <= remaining:
            scheduled.append(item)
            remaining -= item["estimated_minutes"]
        else:
            unscheduled.append(item["id"])

    return {
        "schedule": scheduled,
        "blocked_tasks": blocked,
        "unscheduled_tasks": unscheduled,
        "available_minutes": data.available_minutes,
        "scheduled_minutes": data.available_minutes - remaining,
        "remaining_minutes": remaining,
    }
