# AI TIME

AI TIME is a personal productivity workspace for tasks, focus sessions, and AI-assisted planning. This repository is an MVP foundation: the task manager and focus timer work locally, while AI planning can use Anthropic's API when configured.

## Features

- Add, complete, delete, and prioritize tasks
- Set task importance, estimated duration, and optional deadline
- Generate a time-budgeted task plan with dependency checks
- Focus timer with configurable work and break durations
- Dashboard stats and browser-local persistence
- Optional Claude-powered planning endpoint
- Input validation, tests, and Docker support

## Requirements

- Python 3.11+
- Optional: an Anthropic API key for AI planning

## Run locally

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell
# .venv\Scripts\Activate.ps1

pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000

The app works without an API key; the planner uses a deterministic local fallback. To enable Claude planning, set `ANTHROPIC_API_KEY` and `ANTHROPIC_MODEL` in `.env`. API use may incur separate charges. A Claude subscription and API access are different products.

## Run tests

```bash
pytest
```

## Docker

```bash
docker compose up --build
```

Then open http://127.0.0.1:8000.

## GitHub setup

1. Create a GitHub repository named `ai-time`.
2. Upload the contents of this folder (not the ZIP file itself).
3. Commit the README, code, and tests.
4. Keep `.env` and all real API keys out of GitHub. The included `.env.example` contains placeholders only.

## Project status

This is an early MVP, not a finished autonomous agent platform. It does not yet include user accounts, cloud database persistence, calendar integrations, multi-agent execution, or production-grade deployment controls. Browser data is stored locally in the browser. Add authentication, authorization, durable storage, rate limiting, and monitoring before deploying for multiple users.
