(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const KEY = "ai-time-workspace-v1";
  let tasks = [];
  let activeFilter = "all";
  let focusSessions = 0;
  let secondsLeft = 25 * 60;
  let timerId = null;
  let isBreak = false;

  function load() {
    try {
      const data = JSON.parse(localStorage.getItem(KEY) || "{}");
      tasks = Array.isArray(data.tasks) ? data.tasks.filter(t =>
        t && typeof t.id === "string" && typeof t.title === "string" &&
        typeof t.done === "boolean") : [];
      focusSessions = Number.isInteger(data.focusSessions) ? data.focusSessions : 0;
      $("notes").value = typeof data.notes === "string" ? data.notes : "";
      $("focusMinutes").value = String(data.focusMinutes || 25);
      $("breakMinutes").value = String(data.breakMinutes || 5);
      secondsLeft = Number(data.secondsLeft) > 0 ? data.secondsLeft : Number($("focusMinutes").value) * 60;
    } catch {
      tasks = [];
    }
  }

  function save() {
    try {
      localStorage.setItem(KEY, JSON.stringify({
        tasks, focusSessions, notes: $("notes").value,
        focusMinutes: Number($("focusMinutes").value),
        breakMinutes: Number($("breakMinutes").value),
        secondsLeft
      }));
    } catch {
      $("noteStatus").textContent = "Storage unavailable";
    }
  }

  function safeId() {
    return (globalThis.crypto && crypto.randomUUID)
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }

  function updateStats() {
    const done = tasks.filter(t => t.done).length;
    const rate = tasks.length ? Math.round(done / tasks.length * 100) : 0;
    $("totalCount").textContent = tasks.length;
    $("doneCount").textContent = done;
    $("completionRate").textContent = `${rate}%`;
    $("completionBar").style.width = `${rate}%`;
    $("focusCount").textContent = focusSessions;
    $("taskPill").textContent = `${tasks.length - done} active`;
  }

  function renderTasks() {
    const list = $("taskList");
    list.replaceChildren();
    const visible = tasks.filter(t =>
      activeFilter === "all" ||
      (activeFilter === "active" && !t.done) ||
      (activeFilter === "done" && t.done)
    );
    $("emptyState").hidden = visible.length > 0;

    for (const task of visible) {
      const row = document.createElement("div");
      row.className = `task-item${task.done ? " completed" : ""}`;

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.className = "task-check";
      checkbox.checked = task.done;
      checkbox.setAttribute("aria-label", `Complete ${task.title}`);
      checkbox.addEventListener("change", () => {
        task.done = checkbox.checked;
        save();
        renderTasks();
      });

      const copy = document.createElement("div");
      copy.className = "task-copy";
      const title = document.createElement("div");
      title.className = "task-title";
      title.textContent = task.title;
      const meta = document.createElement("div");
      meta.className = "task-meta";
      const importance = document.createElement("span");
      importance.className = "importance";
      importance.textContent = `${task.importanceLabel} priority`;
      const duration = document.createElement("span");
      duration.textContent = `${task.minutes} min`;
      meta.append(importance, duration);
      if (task.deadline) {
        const deadline = document.createElement("span");
        deadline.textContent = `Due ${new Date(task.deadline).toLocaleString()}`;
        meta.append(deadline);
      }
      copy.append(title, meta);

      const remove = document.createElement("button");
      remove.className = "remove-task";
      remove.type = "button";
      remove.textContent = "×";
      remove.setAttribute("aria-label", `Delete ${task.title}`);
      remove.addEventListener("click", () => {
        tasks = tasks.filter(item => item.id !== task.id);
        save();
        renderTasks();
      });

      row.append(checkbox, copy, remove);
      list.append(row);
    }
    updateStats();
  }

  $("taskForm").addEventListener("submit", event => {
    event.preventDefault();
    const title = $("taskTitle").value.trim();
    if (!title) return;
    const importance = Number($("importance").value);
    const labels = { 3: "Low", 5: "Normal", 8: "High", 10: "Critical" };
    const rawDeadline = $("deadline").value;
    tasks.unshift({
      id: safeId(), title, done: false, importance,
      importanceLabel: labels[importance] || "Normal",
      minutes: Number($("duration").value),
      deadline: rawDeadline ? new Date(rawDeadline).toISOString() : null
    });
    $("taskTitle").value = "";
    $("deadline").value = "";
    save();
    renderTasks();
  });

  document.querySelectorAll("[data-filter]").forEach(button => {
    button.addEventListener("click", () => {
      activeFilter = button.dataset.filter;
      document.querySelectorAll("[data-filter]").forEach(b => b.classList.toggle("active", b === button));
      renderTasks();
    });
  });

  $("clearDone").addEventListener("click", () => {
    tasks = tasks.filter(t => !t.done);
    save();
    renderTasks();
  });

  $("notes").addEventListener("input", () => {
    save();
    $("noteStatus").textContent = "Saved locally";
  });

  function renderTimer() {
    const mins = Math.floor(secondsLeft / 60);
    const secs = secondsLeft % 60;
    $("timer").textContent = `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
    $("timerMode").textContent = isBreak ? "BREAK SESSION" : "FOCUS SESSION";
  }

  function stopTimer() {
    if (timerId !== null) clearInterval(timerId);
    timerId = null;
    $("timerStart").textContent = "Resume";
  }

  function tick() {
    secondsLeft -= 1;
    if (secondsLeft <= 0) {
      stopTimer();
      if (!isBreak) {
        focusSessions += 1;
        isBreak = true;
        secondsLeft = Number($("breakMinutes").value) * 60;
        $("timerMessage").textContent = "Focus session complete. Take a real break.";
      } else {
        isBreak = false;
        secondsLeft = Number($("focusMinutes").value) * 60;
        $("timerMessage").textContent = "Break finished. Ready for another session?";
      }
      save();
      updateStats();
    }
    renderTimer();
  }

  $("timerStart").addEventListener("click", () => {
    if (timerId !== null) {
      stopTimer();
      $("timerMessage").textContent = "Timer paused.";
      return;
    }
    $("timerStart").textContent = "Pause";
    $("timerMessage").textContent = "Protect this time for one task.";
    timerId = setInterval(tick, 1000);
  });

  $("timerReset").addEventListener("click", () => {
    stopTimer();
    isBreak = false;
    secondsLeft = Number($("focusMinutes").value) * 60;
    $("timerMessage").textContent = "Ready when you are.";
    renderTimer();
    save();
  });

  ["focusMinutes", "breakMinutes"].forEach(id => $(id).addEventListener("change", () => {
    if (timerId !== null) stopTimer();
    if (!isBreak) secondsLeft = Number($("focusMinutes").value) * 60;
    else secondsLeft = Number($("breakMinutes").value) * 60;
    renderTimer();
    save();
  }));

  function renderPlan(data) {
    const output = $("planOutput");
    output.replaceChildren();

    const heading = document.createElement("h3");
    heading.textContent = "Your suggested schedule";
    const summary = document.createElement("p");
    summary.className = "plan-summary";
    summary.textContent = `${data.scheduled_minutes} of ${data.available_minutes} minutes scheduled · ${data.remaining_minutes} minutes remaining.`;
    const list = document.createElement("div");
    list.className = "plan-list";

    if (!data.schedule || data.schedule.length === 0) {
      const empty = document.createElement("p");
      empty.className = "muted";
      empty.textContent = "No tasks fit this time budget yet. Add tasks or increase your available time.";
      list.append(empty);
    } else {
      data.schedule.forEach((task, index) => {
        const row = document.createElement("div");
        row.className = "plan-task";
        const number = document.createElement("span");
        number.className = "plan-number";
        number.textContent = String(index + 1).padStart(2, "0");
        const body = document.createElement("div");
        const title = document.createElement("strong");
        title.textContent = task.title;
        const detail = document.createElement("p");
        detail.textContent = `${task.estimated_minutes} minutes · Priority score ${task.priority_score}. ${task.reason.join(". ")}.`;
        body.append(title, detail);
        row.append(number, body);
        list.append(row);
      });
    }

    output.append(heading, summary, list);

    if (data.blocked_tasks?.length || data.unscheduled_tasks?.length) {
      const warning = document.createElement("p");
      warning.className = "warning";
      const parts = [];
      if (data.blocked_tasks?.length) parts.push(`Blocked by dependencies: ${data.blocked_tasks.join(", ")}.`);
      if (data.unscheduled_tasks?.length) parts.push(`Do not fit the available time: ${data.unscheduled_tasks.join(", ")}.`);
      warning.textContent = parts.join(" ");
      output.append(warning);
    }

    if (data.ai_advice) {
      const advice = document.createElement("div");
      advice.className = "ai-advice";
      advice.textContent = data.ai_advice;
      output.append(advice);
    }
  }

  $("planForm").addEventListener("submit", async event => {
    event.preventDefault();
    const objective = $("objective").value.trim();
    if (!objective) return;

    const output = $("planOutput");
    output.replaceChildren();
    const loading = document.createElement("p");
    loading.className = "loading";
    loading.textContent = "Building a plan…";
    output.append(loading);

    const apiTasks = tasks.map(task => ({
      id: task.id,
      title: task.title,
      importance: task.importance,
      estimated_minutes: task.minutes,
      deadline: task.deadline,
      dependencies: [],
      status: task.done ? "completed" : "pending"
    }));

    try {
      const response = await fetch("/api/plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          objective,
          tasks: apiTasks,
          available_minutes: Number($("availableMinutes").value),
          use_claude: $("useClaude").checked
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || "Could not build the plan.");
      renderPlan(data);
    } catch (error) {
      output.replaceChildren();
      const message = document.createElement("p");
      message.className = "error";
      message.textContent = error instanceof Error ? error.message : "Something went wrong.";
      output.append(message);
    }
  });

  async function healthCheck() {
    try {
      const response = await fetch("/api/health");
      const data = await response.json();
      $("connection").textContent = data.claude_configured ? "API online · Claude ready" : "API online · Local mode";
    } catch {
      $("connection").textContent = "API unavailable";
    }
  }

  function updateClock() {
    $("clock").textContent = new Date().toLocaleString([], {
      weekday: "short", month: "short", day: "numeric",
      hour: "2-digit", minute: "2-digit"
    });
  }

  load();
  renderTasks();
  renderTimer();
  updateClock();
  healthCheck();
  setInterval(updateClock, 30000);
})();
