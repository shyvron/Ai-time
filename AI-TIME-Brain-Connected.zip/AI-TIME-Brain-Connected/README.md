# AI TIME — AI Brain Connected (Android source + backend)

This package adds a real cloud AI chat path to the Android app. The model runs on an AI provider; the Android app calls a small backend that keeps the provider API key off the device. This is source code, not a prebuilt APK.

## What is included
- Existing AI TIME productivity app and local owner commands.
- AI BRAIN chat UI with conversation history saved locally.
- Backend URL and app access token settings inside the app.
- Node.js backend using the OpenAI Responses API.
- `render.yaml` blueprint for deploying the backend.
- GitHub Actions workflow that builds a debug APK and stores it as an Actions artifact.

## Setup (tablet-friendly, no computer required)

### 1. Create an AI API key
Create an API key in your AI provider account and check billing/usage limits. API access and ChatGPT subscription are separate; API calls may cost money. Never paste the provider API key into the Android app, a public repository, or a chat.

### 2. Upload this project to your GitHub repository
Upload the files from this ZIP to the root of your repository, preserving the folders (`app/`, `backend/`, `.github/`, etc.). If you already uploaded an earlier AI TIME version, replace/update the project files with this version.

### 3. Deploy the backend on Render
- Open https://render.com/ in your tablet browser and sign in.
- Choose **New → Blueprint** and select your GitHub repository containing `render.yaml`.
- When prompted for environment values, enter `OPENAI_API_KEY` (your provider key) and `AI_TIME_APP_TOKEN` (make a long, random secret that you create; use the exact same token in the app).
- Keep `OPENAI_MODEL` as `gpt-5-mini` unless you intentionally choose a model available to your API account.
- Deploy, then copy the HTTPS service URL, for example `https://your-service.onrender.com`. Do not use the example literally.
- Test `https://YOUR-SERVICE/health` in a browser. It should return JSON with `ok: true` and `modelConfigured: true`.

### 4. Build the Android APK using GitHub Actions
- In your repository, open **Actions**. Enable workflows if GitHub asks.
- Run **Build AI TIME APK** using **Run workflow**, or push a commit to `main`/`master`.
- When the run succeeds, open the run, scroll to **Artifacts**, and download `AI-TIME-debug-APK`.
- Extract the downloaded artifact ZIP on your tablet and tap `app-debug.apk` to install. Android may ask you to allow installs from your browser/files app. Only install APKs you built or trust.

### 5. Connect AI TIME to the backend
- Open AI TIME and find **AI BRAIN**.
- Enter your deployed HTTPS backend URL (no trailing slash required).
- Enter the same `AI_TIME_APP_TOKEN` value you set on Render.
- Tap **Save connection settings**, ask a question, and press **Ask AI TIME**.

## Security and cost
- The provider API key belongs only in the backend's environment settings. Never put it in Android code or GitHub.
- Keep your app token private. If it leaks, rotate it in Render and in the app.
- The backend includes a basic per-IP throttle, but it is a starter implementation, not a complete production security system. Add a managed rate limiter and monitoring before a public launch.
- API calls may incur charges. Set usage limits/budget alerts in your provider account.
- The app sends chat messages and recent chat history to your backend and AI provider to generate replies. Do not send secrets or sensitive information.
- A working Wi-Fi/mobile data connection is required. This cannot force the tablet to remain online all the time.

## Limits
- The AI brain answers in chat. It does not automatically operate the device, browse arbitrary websites, or execute app commands. Local commands continue to run through the app's local command handler.
- Voice input/output is not implemented in this version.
- This package has not been compiled on an Android SDK in this environment. Use the GitHub Actions workflow to perform the build and review its result.
