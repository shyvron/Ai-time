package com.aitime.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.net.HttpURLConnection
import java.net.URL

private val Night = Color(0xFF090D18)
private val Panel = Color(0xFF141E31)
private val Panel2 = Color(0xFF1B2840)
private val Purple = Color(0xFFA99AFF)
private val Cyan = Color(0xFF74E2E7)
private val Green = Color(0xFF75E2B3)
private val Muted = Color(0xFF9AA8C1)
private val White = Color(0xFFF1F4FF)

data class AiChatMessage(val role: String, val content: String)

data class AiTask(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val importance: Int = 5,
    val minutes: Int = 30,
    val done: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Purple,
                    secondary = Cyan,
                    background = Night,
                    surface = Panel,
                    onPrimary = Night,
                    onBackground = White,
                    onSurface = White
                )
            ) {
                AiTimeApp(applicationContext)
            }
        }
    }
}

@Composable
private fun AiTimeApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("ai_time_data", Context.MODE_PRIVATE) }
    var tasks by remember { mutableStateOf(loadTasks(prefs)) }
    var notes by remember { mutableStateOf(prefs.getString("notes", "") ?: "") }
    var newTask by remember { mutableStateOf("") }
    var importance by remember { mutableIntStateOf(5) }
    var minutes by remember { mutableIntStateOf(30) }
    var timerMinutes by remember { mutableIntStateOf(25) }
    var breakMinutes by remember { mutableIntStateOf(5) }
    var secondsLeft by remember { mutableIntStateOf(25 * 60) }
    var isRunning by remember { mutableStateOf(false) }
    var isBreak by remember { mutableStateOf(false) }
    var focusSessions by remember { mutableIntStateOf(prefs.getInt("focus_sessions", 0)) }
    var objective by remember { mutableStateOf("") }
    var plan by remember { mutableStateOf("") }
    var ownerCommand by remember { mutableStateOf("") }
    var commandFeedback by remember { mutableStateOf("Try: add task study, start timer, pause timer, reset timer, show tasks, or save note ...") }
    var aiBackendUrl by remember { mutableStateOf(prefs.getString("ai_backend_url", "") ?: "") }
    var aiAppToken by remember { mutableStateOf(prefs.getString("ai_app_token", "") ?: "") }
    var aiChatInput by remember { mutableStateOf("") }
    var aiChatStatus by remember { mutableStateOf("Connect a deployed AI TIME backend to enable the AI brain.") }
    var aiThinking by remember { mutableStateOf(false) }
    var aiChatHistory by remember { mutableStateOf(loadAiChatHistory(prefs)) }
    val scope = rememberCoroutineScope()

    fun persistTasks(updated: List<AiTask>) {
        tasks = updated
        prefs.edit().putString("tasks", tasksToJson(updated)).apply()
    }

    LaunchedEffect(isRunning) {
        while (isRunning) {
            delay(1000)
            if (secondsLeft > 1) {
                secondsLeft -= 1
            } else {
                if (!isBreak) {
                    focusSessions += 1
                    prefs.edit().putInt("focus_sessions", focusSessions).apply()
                    isBreak = true
                    secondsLeft = breakMinutes * 60
                } else {
                    isBreak = false
                    secondsLeft = timerMinutes * 60
                }
                isRunning = false
            }
        }
    }

    val completed = tasks.count { it.done }
    val active = tasks.size - completed
    val progress = if (tasks.isEmpty()) 0 else (completed * 100 / tasks.size)

    Surface(modifier = Modifier.fillMaxSize(), color = Night) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 36.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("AI TIME", color = White, fontSize = 27.sp, fontWeight = FontWeight.Black)
                        Text("YOUR PERSONAL PRODUCTIVITY OS", color = Purple, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    }
                    Box(
                        modifier = Modifier.size(44.dp).background(Panel2, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("✦", color = Cyan, fontSize = 24.sp)
                    }
                }
            }
            item {
                Column(
                    modifier = Modifier.fillMaxWidth()
                        .background(Panel, RoundedCornerShape(22.dp))
                        .padding(20.dp)
                ) {
                    Text("Make room for", color = White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Text("meaningful work.", color = Purple, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Plan your time, protect your focus, and turn goals into clear next steps.", color = Muted, fontSize = 13.sp)
                }
            }
            item {
                Column(
                    modifier = Modifier.fillMaxWidth()
                        .background(Panel, RoundedCornerShape(20.dp)).padding(18.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("OWNER COMMAND CENTER", color = Cyan, fontSize = 10.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text("LOCAL", color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Give AI TIME a command.", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Commands run inside this app on your tablet.", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = ownerCommand,
                        onValueChange = { if (it.length <= 300) ownerCommand = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Example: add task finish homework") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = {
                            val command = ownerCommand.trim()
                            val lower = command.lowercase()
                            commandFeedback = when {
                                lower.startsWith("add task ") && command.substringAfter("add task ").isNotBlank() -> {
                                    val title = command.substringAfter("add task ").trim()
                                    persistTasks(listOf(AiTask(title = title, importance = 5, minutes = 30)) + tasks)
                                    "Done — added task: $title"
                                }
                                lower == "start timer" -> { isRunning = true; "Done — focus timer started." }
                                lower == "pause timer" -> { isRunning = false; "Done — timer paused." }
                                lower == "reset timer" -> { isRunning = false; isBreak = false; secondsLeft = timerMinutes * 60; "Done — timer reset." }
                                lower == "show tasks" -> {
                                    if (tasks.isEmpty()) "You have no tasks yet."
                                    else "Your tasks: " + tasks.filterNot { it.done }.take(8).joinToString { it.title }.ifBlank { "All tasks are complete." }
                                }
                                lower.startsWith("complete ") -> {
                                    val query = command.substringAfter("complete ").trim()
                                    val match = tasks.firstOrNull { !it.done && it.title.contains(query, ignoreCase = true) }
                                    if (match == null || query.isBlank()) "I couldn't find an open task matching that name."
                                    else { persistTasks(tasks.map { if (it.id == match.id) it.copy(done = true) else it }); "Done — completed: ${match.title}" }
                                }
                                lower.startsWith("save note ") && command.substringAfter("save note ").isNotBlank() -> {
                                    notes = (notes + if (notes.isBlank()) "" else "\n" + command.substringAfter("save note ").trim())
                                    prefs.edit().putString("notes", notes).apply()
                                    "Done — saved your note."
                                }
                                lower.startsWith("plan ") && command.substringAfter("plan ").isNotBlank() -> {
                                    objective = command.substringAfter("plan ").trim()
                                    plan = createLocalPlan(objective, tasks)
                                    "Done — created a plan below in AI Planning Studio."
                                }
                                lower == "help" -> "Commands: add task [name], complete [task name], show tasks, start timer, pause timer, reset timer, save note [text], plan [goal]."
                                command.isBlank() -> "Type a command first. Type help to see supported commands."
                                else -> "I don't know that command yet. Type help to see supported commands."
                            }
                            ownerCommand = ""
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Run command  →") }
                    Spacer(Modifier.height(8.dp))
                    Text(commandFeedback, color = Cyan, fontSize = 12.sp, lineHeight = 18.sp)
                    Text("Local commands control only features inside AI TIME.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
            item {
                Column(
                    modifier = Modifier.fillMaxWidth()
                        .background(Panel, RoundedCornerShape(20.dp)).padding(18.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("AI BRAIN", color = Purple, fontSize = 11.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text(if (aiBackendUrl.startsWith("https://")) "CLOUD READY" else "NOT CONNECTED", color = if (aiBackendUrl.startsWith("https://")) Green else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Talk to the AI model", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("AI TIME sends your message to your own secure backend. Keep the model API key on the server, never in this app.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = aiBackendUrl,
                        onValueChange = { aiBackendUrl = it; prefs.edit().putString("ai_backend_url", it.trim()).apply() },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Backend URL (HTTPS)") },
                        placeholder = { Text("https://your-service.onrender.com") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = aiAppToken,
                        onValueChange = { aiAppToken = it; prefs.edit().putString("ai_app_token", it).apply() },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("App access token") },
                        placeholder = { Text("Set the same token on your backend") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {
                        prefs.edit().putString("ai_backend_url", aiBackendUrl.trim()).putString("ai_app_token", aiAppToken).apply()
                        aiChatStatus = if (aiBackendUrl.trim().startsWith("https://")) "Backend URL saved. Send a message to test the connection." else "Enter a valid HTTPS backend URL first."
                    }, modifier = Modifier.fillMaxWidth()) { Text("Save connection settings") }
                    Spacer(Modifier.height(10.dp))
                    aiChatHistory.takeLast(8).forEach { entry ->
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                .background(if (entry.role == "user") Panel2 else Night, RoundedCornerShape(12.dp)).padding(10.dp)
                        ) {
                            Text(if (entry.role == "user") "YOU" else "AI TIME", color = if (entry.role == "user") Cyan else Purple, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(3.dp))
                            Text(entry.content, color = White, fontSize = 13.sp, lineHeight = 18.sp)
                        }
                    }
                    OutlinedTextField(
                        value = aiChatInput,
                        onValueChange = { if (it.length <= 3000) aiChatInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Ask AI TIME anything") },
                        placeholder = { Text("Explain something, help me code, plan my day…") }
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        enabled = !aiThinking && aiChatInput.isNotBlank(),
                        onClick = {
                            val question = aiChatInput.trim()
                            val url = aiBackendUrl.trim()
                            val token = aiAppToken.trim()
                            if (!url.startsWith("https://")) {
                                aiChatStatus = "Set your HTTPS backend URL first. Follow SETUP_AI_BRAIN.md."
                            } else {
                                val previousHistory = aiChatHistory.takeLast(10)
                                aiChatHistory = (aiChatHistory + AiChatMessage("user", question)).takeLast(12)
                                prefs.edit().putString("ai_chat_history", aiChatHistoryToJson(aiChatHistory)).apply()
                                aiChatInput = ""
                                aiThinking = true
                                aiChatStatus = "AI TIME is thinking…"
                                scope.launch {
                                    try {
                                        val answer = withContext(Dispatchers.IO) { requestAiTimeReply(url, token, question, previousHistory) }
                                        aiChatHistory = (aiChatHistory + AiChatMessage("assistant", answer)).takeLast(12)
                                        prefs.edit().putString("ai_chat_history", aiChatHistoryToJson(aiChatHistory)).apply()
                                        aiChatStatus = "Connected. AI response received."
                                    } catch (e: Exception) {
                                        aiChatStatus = "Could not reach AI: ${e.message ?: "check backend URL, token, and internet"}"
                                    } finally {
                                        aiThinking = false
                                    }
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (aiThinking) "Thinking…" else "Ask AI TIME  →") }
                    Spacer(Modifier.height(6.dp))
                    Text(aiChatStatus, color = Cyan, fontSize = 11.sp, lineHeight = 16.sp)
                    Text("Requires an internet connection, a deployed backend, and an AI API account. API usage may cost money.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    StatCard("TASKS", tasks.size.toString(), Modifier.weight(1f), Purple)
                    StatCard("DONE", completed.toString(), Modifier.weight(1f), Green)
                    StatCard("PROGRESS", "$progress%", Modifier.weight(1f), Cyan)
                }
            }
            item {
                Column(
                    modifier = Modifier.fillMaxWidth()
                        .background(Panel, RoundedCornerShape(20.dp)).padding(18.dp)
                ) {
                    Text("FOCUS TIMER", color = Purple, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(if (isBreak) "Break time" else "Deep work", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "%02d:%02d".format(secondsLeft / 60, secondsLeft % 60),
                        color = Cyan, fontSize = 48.sp, fontWeight = FontWeight.ExtraBold
                    )
                    Text("$focusSessions focus sessions completed", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { isRunning = !isRunning }, modifier = Modifier.weight(1f)) {
                            Icon(if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text(if (isRunning) "Pause" else "Start")
                        }
                        OutlinedButton(onClick = {
                            isRunning = false
                            isBreak = false
                            secondsLeft = timerMinutes * 60
                        }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.Refresh, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text("Reset")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Focus minutes", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.width(8.dp))
                        listOf(15, 25, 45).forEach { value ->
                            FilterChip(
                                selected = timerMinutes == value,
                                onClick = {
                                    timerMinutes = value
                                    if (!isBreak && !isRunning) secondsLeft = value * 60
                                },
                                label = { Text("$value") }
                            )
                            Spacer(Modifier.width(4.dp))
                        }
                    }
                }
            }
            item {
                Column(
                    modifier = Modifier.fillMaxWidth()
                        .background(Panel, RoundedCornerShape(20.dp)).padding(18.dp)
                ) {
                    Text("TASK MANAGER", color = Purple, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Move one thing forward.", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = newTask,
                        onValueChange = { if (it.length <= 160) newTask = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("What needs to get done?") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Priority", color = Muted, fontSize = 12.sp)
                        listOf(3, 5, 8, 10).forEach { value ->
                            FilterChip(
                                selected = importance == value,
                                onClick = { importance = value },
                                label = { Text(value.toString()) }
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Estimate", color = Muted, fontSize = 12.sp)
                        listOf(15, 30, 60).forEach { value ->
                            FilterChip(
                                selected = minutes == value,
                                onClick = { minutes = value },
                                label = { Text("$value min") }
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val title = newTask.trim()
                            if (title.isNotEmpty()) {
                                persistTasks(listOf(AiTask(title = title, importance = importance, minutes = minutes)) + tasks)
                                newTask = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = newTask.trim().isNotEmpty()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Add task")
                    }
                    Spacer(Modifier.height(10.dp))
                    if (tasks.isEmpty()) {
                        Text("No tasks yet. Add your first task above.", color = Muted, fontSize = 13.sp)
                    } else {
                        tasks.forEach { task ->
                            Row(
                                modifier = Modifier.fillMaxWidth()
                                    .padding(vertical = 5.dp)
                                    .background(Panel2, RoundedCornerShape(12.dp))
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = task.done,
                                    onCheckedChange = { checked ->
                                        persistTasks(tasks.map { if (it.id == task.id) it.copy(done = checked) else it })
                                    }
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        task.title,
                                        color = if (task.done) Muted else White,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text("${task.minutes} min • Priority ${task.importance}", color = Muted, fontSize = 11.sp)
                                }
                                IconButton(onClick = { persistTasks(tasks.filterNot { it.id == task.id }) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete task", tint = Color(0xFFFF879B))
                                }
                            }
                        }
                    }
                    Text("$active tasks remaining", color = Muted, fontSize = 11.sp)
                }
            }
            item {
                Column(
                    modifier = Modifier.fillMaxWidth()
                        .background(Panel, RoundedCornerShape(20.dp)).padding(18.dp)
                ) {
                    Text("AI PLANNING STUDIO", color = Purple, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Turn a goal into a plan.", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = objective,
                        onValueChange = { if (it.length <= 1000) objective = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("What do you want to accomplish?") },
                        minLines = 3
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { plan = createLocalPlan(objective, tasks) },
                        enabled = objective.trim().isNotEmpty(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Create my plan ↗")
                    }
                    if (plan.isNotBlank()) {
                        Spacer(Modifier.height(12.dp))
                        Text(plan, color = White, fontSize = 13.sp, lineHeight = 20.sp)
                        Spacer(Modifier.height(6.dp))
                        Text("This is a local planning helper, not Claude-generated advice.", color = Muted, fontSize = 10.sp)
                    }
                }
            }
            item {
                Column(
                    modifier = Modifier.fillMaxWidth()
                        .background(Panel, RoundedCornerShape(20.dp)).padding(18.dp)
                ) {
                    Text("QUICK NOTES", color = Purple, fontSize = 10.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = notes,
                        onValueChange = {
                            notes = it
                            prefs.edit().putString("notes", it).apply()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Capture an idea before it disappears…") },
                        minLines = 4
                    )
                    Spacer(Modifier.height(5.dp))
                    Text("Notes are saved on this device.", color = Muted, fontSize = 10.sp)
                }
            }
            item {
                Text("AI TIME • Build momentum, not pressure.", color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp))
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier, accent: Color) {
    Column(
        modifier = modifier.background(Panel, RoundedCornerShape(15.dp)).padding(12.dp)
    ) {
        Text(label, color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(8.dp))
        Text(value, color = accent, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
    }
}

private fun createLocalPlan(objective: String, tasks: List<AiTask>): String {
    val openTasks = tasks.filterNot { it.done }.sortedWith(
        compareByDescending<AiTask> { it.importance }.thenBy { it.minutes }
    )
    val lines = mutableListOf(
        "YOUR PLAN",
        "",
        "Goal: ${objective.trim()}",
        "",
        "1. Define what a successful result looks like.",
        "2. Start with one small action you can finish today."
    )
    if (openTasks.isNotEmpty()) {
        lines += ""
        lines += "TASKS TO CONSIDER"
        openTasks.take(5).forEachIndexed { index, task ->
            lines += "${index + 3}. ${task.title} (${task.minutes} min, priority ${task.importance}/10)"
        }
    } else {
        lines += "3. Add your first task to make this plan actionable."
    }
    lines += ""
    lines += "Tip: Pick one task, start a focus session, and review your progress afterward."
    return lines.joinToString("\n")
}

private fun aiChatHistoryToJson(messages: List<AiChatMessage>): String {
    val array = JSONArray()
    messages.takeLast(12).forEach { item ->
        array.put(JSONObject().put("role", item.role).put("content", item.content))
    }
    return array.toString()
}

private fun loadAiChatHistory(prefs: android.content.SharedPreferences): List<AiChatMessage> {
    return try {
        val array = JSONArray(prefs.getString("ai_chat_history", "[]") ?: "[]")
        (0 until array.length()).mapNotNull { index ->
            val item = array.optJSONObject(index) ?: return@mapNotNull null
            val role = item.optString("role")
            val content = item.optString("content")
            if ((role == "user" || role == "assistant") && content.isNotBlank()) AiChatMessage(role, content) else null
        }.takeLast(12)
    } catch (_: Exception) { emptyList() }
}

private fun requestAiTimeReply(
    baseUrl: String,
    appToken: String,
    message: String,
    history: List<AiChatMessage>
): String {
    val cleanBase = baseUrl.trim().trimEnd('/')
    require(cleanBase.startsWith("https://")) { "Use an HTTPS backend URL." }
    val connection = (URL("$cleanBase/chat").openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 15000
        readTimeout = 60000
        doOutput = true
        setRequestProperty("Content-Type", "application/json; charset=utf-8")
        if (appToken.isNotBlank()) setRequestProperty("x-ai-time-token", appToken)
    }
    try {
        val historyJson = JSONArray()
        history.takeLast(10).forEach { item ->
            historyJson.put(JSONObject().put("role", item.role).put("content", item.content))
        }
        val body = JSONObject().put("message", message).put("history", historyJson).toString()
        connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val responseText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        val response = try { JSONObject(responseText) } catch (_: Exception) { JSONObject() }
        if (code !in 200..299) {
            val detail = response.optString("error").ifBlank { "HTTP $code" }
            throw IllegalStateException(detail.take(240))
        }
        return response.optString("reply").ifBlank { "The AI service returned an empty reply. Try again." }
    } finally {
        connection.disconnect()
    }
}

private fun loadTasks(prefs: android.content.SharedPreferences): List<AiTask> {
    return try {
        val array = JSONArray(prefs.getString("tasks", "[]"))
        (0 until array.length()).mapNotNull { index ->
            val obj = array.optJSONObject(index) ?: return@mapNotNull null
            AiTask(
                id = obj.optString("id", UUID.randomUUID().toString()),
                title = obj.optString("title", ""),
                importance = obj.optInt("importance", 5),
                minutes = obj.optInt("minutes", 30),
                done = obj.optBoolean("done", false)
            ).takeIf { it.title.isNotBlank() }
        }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun tasksToJson(tasks: List<AiTask>): String {
    val array = JSONArray()
    tasks.forEach { task ->
        array.put(
            JSONObject()
                .put("id", task.id)
                .put("title", task.title)
                .put("importance", task.importance)
                .put("minutes", task.minutes)
                .put("done", task.done)
        )
    }
    return array.toString()
}
