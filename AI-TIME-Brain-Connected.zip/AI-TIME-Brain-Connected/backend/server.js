import express from "express";

const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "24kb" }));

const PORT = Number(process.env.PORT || 3000);
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const APP_TOKEN = process.env.AI_TIME_APP_TOKEN;
const MODEL = process.env.OPENAI_MODEL || "gpt-5-mini";

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "AI TIME brain", modelConfigured: Boolean(OPENAI_API_KEY) });
});

// Small in-memory per-IP throttle; add a managed rate limiter for production.
const recentRequests = new Map();
app.post("/chat", async (req, res) => {
  if (!OPENAI_API_KEY) return res.status(503).json({ error: "Backend owner must configure OPENAI_API_KEY." });
  if (!APP_TOKEN) return res.status(503).json({ error: "Backend owner must configure AI_TIME_APP_TOKEN." });
  if (req.get("x-ai-time-token") !== APP_TOKEN) return res.status(401).json({ error: "Invalid app access token." });

  const now = Date.now();
  const ip = req.ip || "unknown";
  const recent = (recentRequests.get(ip) || []).filter((t) => now - t < 60_000);
  if (recent.length >= 12) return res.status(429).json({ error: "Too many messages. Please wait a minute." });
  recent.push(now);
  recentRequests.set(ip, recent);

  const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
  if (!message) return res.status(400).json({ error: "A message is required." });
  if (message.length > 3000) return res.status(413).json({ error: "Message is too long (maximum 3000 characters)." });

  const history = Array.isArray(req.body?.history) ? req.body.history.slice(-10) : [];
  const input = [];
  for (const item of history) {
    if (!item || !["user", "assistant"].includes(item.role) || typeof item.content !== "string") continue;
    input.push({ role: item.role, content: item.content.slice(0, 3000) });
  }
  input.push({ role: "user", content: message });

  try {
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: MODEL,
        instructions: "You are AI TIME, a helpful personal AI assistant owned and configured by the app's user. Be clear, useful, honest, and safe. You can help with general knowledge, learning, writing, coding, planning, and productivity. Do not claim to control the device or perform actions in other apps. You may explain supported AI TIME commands, but do not claim an action was executed unless the app confirms it. If uncertain, say so.",
        input,
        max_output_tokens: 800
      }),
      signal: AbortSignal.timeout(55_000)
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const detail = data?.error?.message || `AI provider returned HTTP ${upstream.status}`;
      console.error("AI provider request failed:", upstream.status, detail);
      return res.status(502).json({ error: "The AI service could not answer. Check API access, model, and billing settings." });
    }
    const reply = typeof data.output_text === "string" ? data.output_text : (data.output || [])
      .flatMap((item) => item.content || [])
      .filter((part) => part.type === "output_text" && typeof part.text === "string")
      .map((part) => part.text).join("\n");
    if (!reply.trim()) return res.status(502).json({ error: "The AI provider returned no text. Please retry." });
    return res.json({ reply: reply.trim(), model: MODEL });
  } catch (error) {
    console.error("AI request error:", error?.message || error);
    return res.status(502).json({ error: "Could not connect to the AI provider. Please try again." });
  }
});

app.listen(PORT, "0.0.0.0", () => console.log(`AI TIME brain backend listening on ${PORT}`));
